package com.hellohasan.sqlite_multiple_three_tables_crud.features.subject_crud;

public interface SubjectCrudListener {
    void onSubjectListUpdate(boolean isUpdate);
}