package com.hellohasan.sqlite_multiple_three_tables_crud.features.student_crud;

public interface StudentCrudListener {
    void onStudentListUpdate(boolean isUpdated);
}
